﻿namespace BankAccountSystem.Models
{
    public enum Client
    {
        Individual,
        Company
    }
}
