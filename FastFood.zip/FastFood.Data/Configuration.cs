namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=.;Database=FastFood;Trusted_Connection=True";
	}
}